# single_file.py

# --- IMPORTS ---
import os
import sys
import sqlite3
import tkinter as tk
import urllib.request
import shutil
import subprocess
import time
import threading
import unicodedata
import re
from tkinter import ttk, messagebox, simpledialog, filedialog
from datetime import datetime
from PIL import Image, ImageTk
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from barcode import Code128
from barcode.writer import ImageWriter

# --- HELPERS ---
def resource_path(rel_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, rel_path)
    return os.path.join(os.path.abspath(os.path.dirname(sys.argv[0])), rel_path)

def format_now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# --- CONSTANTS ---
BASE_DIR = os.path.abspath(os.path.dirname(sys.argv[0]))
APP_DB_PATH = os.path.join(BASE_DIR, "app_data.db")
ORDER_DB_PATH = os.path.join(BASE_DIR, "siparis.db")
ORDERS_FOLDER = os.path.join(BASE_DIR, "siparisler")
REMOTE_BASE = "mega:Malzeme_Talep_Formu"

# rclone / updater assumed to be alongside exe
RCLONE_CMD = os.path.join(BASE_DIR, "rclone.exe") if os.path.exists(os.path.join(BASE_DIR, "rclone.exe")) else "rclone"
UPDATER_CMD = os.path.join(BASE_DIR, "updater.exe") if os.path.exists(os.path.join(BASE_DIR, "updater.exe")) else "updater.exe"

# Sync state
auto_sync_enabled = False
sync_lock = threading.Lock()
last_local_db_mtime = None
last_local_folder_mtime = None
last_remote_db_mtime = None
last_remote_folder_mtime = None

# --- RCLONE / CONFIG HANDLING ---
def _rclone_run(args, config_path=None, timeout=30):
    cmd = [RCLONE_CMD]
    if config_path:
        cmd.append(f"--config={config_path}")
    cmd += args
    kwargs = {"capture_output": True, "text": True}
    if sys.platform == "win32":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        kwargs["startupinfo"] = si
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    try:
        return subprocess.run(cmd, timeout=timeout, **kwargs)
    except subprocess.TimeoutExpired as e:
        return subprocess.CompletedProcess(cmd, 1, stdout="", stderr=f"Timeout: {e}")
    except FileNotFoundError:
        return subprocess.CompletedProcess(cmd, 1, stdout="", stderr="rclone executable not found")
    except Exception as e:
        return subprocess.CompletedProcess(cmd, 1, stdout="", stderr=str(e))

def get_setting(key):
    conn = sqlite3.connect(APP_DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT value FROM settings WHERE key=?", (key,))
    val = cur.fetchone()
    conn.close()
    return val[0] if val else None

def set_setting(key, value):
    conn = sqlite3.connect(APP_DB_PATH)
    cur = conn.cursor()
    cur.execute("REPLACE INTO settings(key,value) VALUES(?,?)", (key, value))
    conn.commit()
    conn.close()

def get_persisted_rclone_conf():
    path = get_setting("rclone_conf")
    if path and os.path.exists(path):
        return path
    default = os.path.join(BASE_DIR, "rclone.conf")
    if os.path.exists(default):
        return default
    return None

def ensure_rclone_config(parent) -> str | None:
    existing = get_persisted_rclone_conf()
    if existing and messagebox.askyesno("rclone config", f"Varsayılan rclone.conf kullanılsın mı?\n{existing}"):
        return existing
    path = filedialog.askopenfilename(parent=parent, title="rclone.conf seçin",
                                      filetypes=[("Rclone Config", "*.conf"), ("Tüm Dosyalar", "*.*")])
    if not path:
        return None
    if messagebox.askyesno("Varsayılan Yap", "Bu rclone.conf'u varsayılan yapılsın mı?"):
        try:
            dest = os.path.join(BASE_DIR, "rclone.conf")
            shutil.copy2(path, dest)
            set_setting("rclone_conf", dest)
            return dest
        except Exception as e:
            messagebox.showwarning("Kopyalama Hatası", f"Varsayılan kopyalanamadı: {e}")
            return path
    else:
        set_setting("rclone_conf", path)
        return path

def sanitize_name(full_name: str) -> str:
    if not full_name:
        return "unknown"
    s = full_name.strip()
    s = unicodedata.normalize("NFKD", s)
    s = s.encode("ascii", "ignore").decode("ascii")
    s = s.lower()
    s = re.sub(r"[^\w\s-]", "", s)
    parts = s.split()
    if len(parts) == 1:
        return parts[0]
    return f"{parts[0]}_{parts[1][0]}"

def ensure_remote_structure(user_folder, config_path):
    _rclone_run(["mkdir", REMOTE_BASE], config_path=config_path)
    _rclone_run(["mkdir", f"{REMOTE_BASE}/{user_folder}"], config_path=config_path)

# --- UPLOAD / DOWNLOAD (refactored to return status) ---
def upload_order_db_to_cloud(parent, full_name: str, config_path) -> tuple[bool, str | None]:
    if not full_name:
        return False, "Önce kullanıcı seçin."
    user_folder = sanitize_name(full_name)
    user_remote = f"{REMOTE_BASE}/{user_folder}"
    remote_db_path = f"{user_remote}/siparis.db"
    try:
        ensure_remote_structure(user_folder, config_path)
        _rclone_run(["delete", remote_db_path], config_path=config_path)
        res = _rclone_run(["copy", ORDER_DB_PATH, f"{user_remote}/", "--retries=3", "--low-level-retries=10"], config_path=config_path)
        if res.returncode == 0:
            return True, None
        return False, res.stderr.strip()
    except Exception as e:
        return False, str(e)

def download_order_db_from_cloud(parent, full_name: str, config_path) -> tuple[bool, str | None]:
    if not full_name:
        return False, "Önce kullanıcı seçin."
    user_folder = sanitize_name(full_name)
    remote_db_path = f"{REMOTE_BASE}/{user_folder}/siparis.db"
    try:
        try:
            shutil.copy2(ORDER_DB_PATH, ORDER_DB_PATH + ".bak")
        except Exception:
            pass
        res = _rclone_run(["copy", remote_db_path, BASE_DIR], config_path=config_path)
        if res.returncode == 0:
            return True, None
        return False, res.stderr.strip()
    except Exception as e:
        return False, str(e)

def upload_orders_folder_to_cloud(parent, full_name: str, config_path) -> tuple[bool, str | None]:
    if not full_name:
        return False, "Önce kullanıcı seçin."
    if not os.path.isdir(ORDERS_FOLDER):
        return False, "Siparişler klasörü yok."
    user_folder = sanitize_name(full_name)
    user_remote_folder = f"{REMOTE_BASE}/{user_folder}/siparisler"
    try:
        ensure_remote_structure(user_folder, config_path)
        res = _rclone_run([
            "copy",
            ORDERS_FOLDER + os.sep,
            f"{user_remote_folder}/",
            "--retries=3",
            "--low-level-retries=10",
            "--update"
        ], config_path=config_path)
        if res.returncode == 0:
            return True, None
        return False, res.stderr.strip()
    except Exception as e:
        return False, str(e)

def download_orders_folder_from_cloud(parent, full_name: str, config_path) -> tuple[bool, str | None]:
    if not full_name:
        return False, "Önce kullanıcı seçin."
    user_folder = sanitize_name(full_name)
    remote_folder = f"{REMOTE_BASE}/{user_folder}/siparisler"
    try:
        os.makedirs(ORDERS_FOLDER, exist_ok=True)
        res = _rclone_run([
            "copy",
            f"{remote_folder}/",
            ORDERS_FOLDER + "/",
            "--retries=3",
            "--low-level-retries=10",
            "--update"
        ], config_path=config_path)
        if res.returncode == 0:
            return True, None
        return False, res.stderr.strip()
    except Exception as e:
        return False, str(e)

def get_remote_file_mtime(remote_path, config_path):
    res = _rclone_run(["lsl", remote_path], config_path=config_path)
    if res.returncode != 0 or not res.stdout.strip():
        return None
    line = res.stdout.strip().splitlines()[-1]
    parts = line.strip().split()
    if len(parts) < 4:
        return None
    date_part = parts[1]
    time_part = parts[2].split(".")[0]
    try:
        dt = datetime.strptime(f"{date_part} {time_part}", "%Y-%m-%d %H:%M:%S")
        return dt
    except Exception:
        return None

def get_latest_local_mtime(path):
    if not os.path.exists(path):
        return None
    try:
        return datetime.fromtimestamp(os.path.getmtime(path))
    except Exception:
        return None

def get_latest_local_folder_mtime():
    if not os.path.isdir(ORDERS_FOLDER):
        return None
    latest = None
    for root, _, files in os.walk(ORDERS_FOLDER):
        for f in files:
            p = os.path.join(root, f)
            try:
                m = datetime.fromtimestamp(os.path.getmtime(p))
                if not latest or m > latest:
                    latest = m
            except Exception:
                continue
    return latest

# --- eklenen yardımcı fonksiyonlar ---
def set_pending_label(label, message):
    ts = format_now()
    label.config(text=f"{message} — {ts}", fg="blue")

def update_status_label(label, message, success=True):
    ts = format_now()
    if success:
        label.config(text=f"{message} — Bulut güncel: {ts}", fg="green")
    else:
        label.config(text=f"{message} — {ts}", fg="red")

# --- auto_sync_thread (güncellenmiş) ---
def auto_sync_thread(parent, status_label):
    global last_local_db_mtime, last_local_folder_mtime
    global last_remote_db_mtime, last_remote_folder_mtime, auto_sync_enabled
    while True:
        try:
            if not get_current_user():
                time.sleep(5)
                continue
            cfg = get_persisted_rclone_conf()
            if not cfg:
                time.sleep(5)
                continue

            local_db_mtime = get_latest_local_mtime(ORDER_DB_PATH)
            local_folder_mtime = get_latest_local_folder_mtime()
            user = get_current_user()
            user_folder = sanitize_name(user)

            remote_db_path = f"{REMOTE_BASE}/{user_folder}/siparis.db"
            remote_folder_path = f"{REMOTE_BASE}/{user_folder}/siparisler"

            # remote mtimeları al
            remote_db_mtime = get_remote_file_mtime(remote_db_path, cfg)
            remote_folder_mtime = None
            res = _rclone_run(["lsl", "--recursive", f"{remote_folder_path}/"], config_path=cfg)
            if res.returncode == 0 and res.stdout.strip():
                for line in res.stdout.strip().splitlines():
                    parts = line.strip().split()
                    if len(parts) >= 4:
                        date_part = parts[1]
                        time_part = parts[2].split(".")[0]
                        try:
                            dt = datetime.strptime(f"{date_part} {time_part}", "%Y-%m-%d %H:%M:%S")
                            if not remote_folder_mtime or dt > remote_folder_mtime:
                                remote_folder_mtime = dt
                        except Exception:
                            continue

            if auto_sync_enabled:
                # Yerel DB değiştiyse / upload veya çatışma
                if local_db_mtime and (last_local_db_mtime is None or local_db_mtime > last_local_db_mtime):
                    if remote_db_mtime and last_remote_db_mtime and remote_db_mtime > last_remote_db_mtime and remote_db_mtime > local_db_mtime:
                        # Çakışma: uzak daha yeni
                        parent.after(0, lambda: set_pending_label(status_label, "Çakışma tespit edildi, uzak siparis.db indiriliyor"))
                        ok, err = download_order_db_from_cloud(parent, user, cfg)
                        if ok:
                            last_remote_db_mtime = get_remote_file_mtime(remote_db_path, cfg)
                            last_local_db_mtime = get_latest_local_mtime(ORDER_DB_PATH)
                            parent.after(0, lambda: update_status_label(status_label, "Çakışma: Uzak veri tercih edildi", success=True))
                        else:
                            parent.after(0, lambda: update_status_label(status_label, f"İndirme hatası: {err}", success=False))
                    else:
                        parent.after(0, lambda: set_pending_label(status_label, "Yerel siparis.db değişikliği algılandı, buluta yükleniyor"))
                        ok, err = upload_order_db_to_cloud(parent, user, cfg)
                        if ok:
                            last_local_db_mtime = get_latest_local_mtime(ORDER_DB_PATH)
                            last_remote_db_mtime = get_remote_file_mtime(remote_db_path, cfg)
                            parent.after(0, lambda: update_status_label(status_label, "siparis.db buluta senkronlandı", success=True))
                        else:
                            parent.after(0, lambda: update_status_label(status_label, f"Yükleme hatası: {err}", success=False))

                # Yerel klasör değiştiyse upload
                if local_folder_mtime and (last_local_folder_mtime is None or local_folder_mtime > last_local_folder_mtime):
                    parent.after(0, lambda: set_pending_label(status_label, "Siparişler klasöründe değişiklik algılandı, buluta yükleniyor"))
                    ok, err = upload_orders_folder_to_cloud(parent, user, cfg)
                    if ok:
                        last_local_folder_mtime = get_latest_local_folder_mtime()
                        # remote klasör mtime güncelle
                        res2 = _rclone_run(["lsl", "--recursive", f"{remote_folder_path}/"], config_path=cfg)
                        if res2.returncode == 0 and res2.stdout.strip():
                            new_remote = None
                            for line in res2.stdout.strip().splitlines():
                                parts = line.strip().split()
                                if len(parts) >= 4:
                                    date_part = parts[1]
                                    time_part = parts[2].split(".")[0]
                                    try:
                                        dt = datetime.strptime(f"{date_part} {time_part}", "%Y-%m-%d %H:%M:%S")
                                        if not new_remote or dt > new_remote:
                                            new_remote = dt
                                    except Exception:
                                        continue
                            last_remote_folder_mtime = new_remote
                        parent.after(0, lambda: update_status_label(status_label, "Siparişler klasörü buluta senkronlandı", success=True))
                    else:
                        parent.after(0, lambda: update_status_label(status_label, f"Klasör yükleme hatası: {err}", success=False))

                # Uzak db daha yeni -> indir
                if remote_db_mtime and (last_remote_db_mtime is None or remote_db_mtime > last_remote_db_mtime) and (not local_db_mtime or remote_db_mtime > local_db_mtime):
                    parent.after(0, lambda: set_pending_label(status_label, "Uzak siparis.db daha yeni, indiriliyor"))
                    ok, err = download_order_db_from_cloud(parent, user, cfg)
                    if ok:
                        last_remote_db_mtime = get_remote_file_mtime(remote_db_path, cfg)
                        last_local_db_mtime = get_latest_local_mtime(ORDER_DB_PATH)
                        parent.after(0, lambda: update_status_label(status_label, "Uzaktaki siparis.db yerelleştirildi", success=True))
                    else:
                        parent.after(0, lambda: update_status_label(status_label, f"İndirme hatası: {err}", success=False))

                # Uzak klasör daha yeni -> indir
                if remote_folder_mtime and (last_remote_folder_mtime is None or remote_folder_mtime > last_remote_folder_mtime):
                    parent.after(0, lambda: set_pending_label(status_label, "Uzak siparişler klasörü daha yeni, indiriliyor"))
                    ok, err = download_orders_folder_from_cloud(parent, user, cfg)
                    if ok:
                        last_remote_folder_mtime = remote_folder_mtime
                        last_local_folder_mtime = get_latest_local_folder_mtime()
                        parent.after(0, lambda: update_status_label(status_label, "Uzaktaki siparişler klasörü yerelleştirildi", success=True))
                    else:
                        parent.after(0, lambda: update_status_label(status_label, f"Klasör indirme hatası: {err}", success=False))

            # Başlangıçta zamanları ayarla (once)
            if last_local_db_mtime is None:
                last_local_db_mtime = local_db_mtime
            if last_local_folder_mtime is None:
                last_local_folder_mtime = local_folder_mtime
            if last_remote_db_mtime is None:
                last_remote_db_mtime = remote_db_mtime
            if last_remote_folder_mtime is None:
                last_remote_folder_mtime = remote_folder_mtime

        except Exception:
            pass
        time.sleep(8)


# --- DATABASE INIT ---
def init_app_db():
    conn = sqlite3.connect(APP_DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS counter (
            date_key TEXT PRIMARY KEY,
            count INTEGER NOT NULL
        )
    """)
    cur.execute("INSERT OR IGNORE INTO settings(key, value) VALUES('auto_open_folder', '1')")
    conn.commit()
    conn.close()

def init_order_db():
    conn = sqlite3.connect(ORDER_DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            barkod TEXT PRIMARY KEY,
            musteri TEXT,
            siparis_alan TEXT,
            siparis_tarihi TEXT,
            cikis_tarihi TEXT,
            aciklama TEXT,
            iletisim TEXT,
            nakliye TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            barkod TEXT,
            urun_kod TEXT,
            cinsi TEXT,
            miktar TEXT,
            birim TEXT,
            FOREIGN KEY(barkod) REFERENCES orders(barkod)
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS urunler (
            kod TEXT PRIMARY KEY,
            aciklama TEXT
        )
    """)
    conn.commit()
    conn.close()

init_app_db()
init_order_db()

# --- PRODUCT DESCRIPTIONS ---
URUN_ACIKLAMALARI = {
    "EN-LF28": "Enkapsül 28 mm",
    "EN-LF30": "Enkapsül 30 mm",
    "ENca-LF28": "Enkapsül Kalsiyum 28 mm",
    "ENca-LF30": "Enkapsül Kalsiyum 30 mm",
    "FPF-LF30": "Folyo Panel Folyo 30 mm",
    "FPF-LF38": "Folyo Panel Folyo 38 mm",
    "HPG-LF30": "HPL Panel Galvanis 30 mm",
    "HPG-LF40": "HPL Panel Galvanis 40 mm",
    "PPF-LF30": "PVC Panel Folyo 30 mm",
    "PPF-LF40": "PVC Panel Folyo 40 mm",
    "PPG-LF30": "PVC Panel Galvanis 30 mm",
    "PPG-LF40": "PVC Panel Galvanis 40 mm",
    "PPGca-LF28": "PVC Kalsiyum Galvanis 28 mm",
    "PPGca-LF30": "PVC Kalsiyum Galvanis 30 mm",
    "PPGca-LF38": "PVC Kalsiyum Galvanis 38 mm",
    "GKT": "Kuşak Takımı",
    "GKTV": "Kuşak Takımı Vidası",
    "KB": "Kuşak Bandı",
    "AT": "Ayak Tutkalı",
}

def urunleri_aktar():
    conn = sqlite3.connect(ORDER_DB_PATH)
    cur = conn.cursor()
    for kod, aciklama in URUN_ACIKLAMALARI.items():
        cur.execute("INSERT OR IGNORE INTO urunler(kod, aciklama) VALUES (?, ?)", (kod, aciklama))
    conn.commit()
    conn.close()

urunleri_aktar()

# --- RESOURCE VALIDATION ---
FONT_FILE = "DejaVuSans.ttf"
FONT_PATH = resource_path(FONT_FILE)
if not os.path.exists(FONT_PATH):
    messagebox.showerror("Hata", f"'{FONT_FILE}' bulunamadı! Exe ile aynı klasörde olduğundan emin olun.")
    sys.exit(1)
pdfmetrics.registerFont(TTFont("DejaVu", FONT_PATH))

# --- DB UTILITIES ---
def get_users():
    conn = sqlite3.connect(APP_DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT username FROM users")
    users = [r[0] for r in cur.fetchall()]
    conn.close()
    return users

def add_user(username):
    if not username:
        return
    conn = sqlite3.connect(APP_DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute("INSERT INTO users(username) VALUES(?)", (username,))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()

def set_current_user(username):
    conn = sqlite3.connect(APP_DB_PATH)
    cur = conn.cursor()
    cur.execute("REPLACE INTO settings(key,value) VALUES(?,?)", ("current_user", username))
    conn.commit()
    conn.close()

def get_current_user():
    conn = sqlite3.connect(APP_DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT value FROM settings WHERE key = ?", ("current_user",))
    row = cur.fetchone()
    conn.close()
    return row[0] if row else None

def sayac_guncelle(kullanici):
    tarih = datetime.now().strftime("%d%m%y")
    key = f"{tarih}_{kullanici}"
    conn = sqlite3.connect(APP_DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT count FROM counter WHERE date_key = ?", (key,))
    row = cur.fetchone()
    if row:
        new_count = row[0] + 1
        cur.execute("UPDATE counter SET count = ? WHERE date_key = ?", (new_count, key))
    else:
        new_count = 1
        cur.execute("INSERT INTO counter(date_key, count) VALUES(?,?)", (key, new_count))
    conn.commit()
    conn.close()
    return f"{new_count}{kullanici[0].upper()}{tarih}"

def get_urunler():
    conn = sqlite3.connect(ORDER_DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT kod FROM urunler ORDER BY kod")
    lst = [r[0] for r in cur.fetchall()]
    conn.close()
    return lst

def get_urun_aciklama(kod):
    conn = sqlite3.connect(ORDER_DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT aciklama FROM urunler WHERE kod=?", (kod,))
    row = cur.fetchone()
    conn.close()
    return row[0] if row else ""

# --- UI HELPERS ---
def _set_button_loading(btn, text="Yükleniyor..."):
    try:
        btn._orig_text = btn.cget("text")
    except AttributeError:
        btn._orig_text = text
    btn.config(state="disabled", text=text)

def _restore_button(btn):
    orig = getattr(btn, "_orig_text", None)
    if orig:
        btn.config(state="normal", text=orig)
    else:
        btn.config(state="normal")

# --- CLEANUP OLD VERSIONS ---
def cleanup_old_versions(current_version):
    cwd = os.getcwd()
    parent = os.path.dirname(cwd)
    for name in os.listdir(parent):
        full = os.path.join(parent, name)
        if os.path.isdir(full) and name not in (current_version, f'v{current_version}'):
            ver = name.lstrip('v')
            if all(c.isdigit() or c == '.' for c in ver):
                if messagebox.askyesno("Eski Sürüm Sil", f"Eski sürüm klasörü '{name}' bulundu. Silmek ister misin?"):
                    try:
                        shutil.rmtree(full)
                    except Exception as e:
                        messagebox.showerror("Hata", f"Silme başarısız: {e}")

# --- MATERIAL ROW MANAGEMENT ---
malzeme_satirlari = []

def malzeme_satiri_ekle():
    y = 360 + len(malzeme_satirlari) * 30
    combo = ttk.Combobox(form_pencere, values=get_urunler(), width=18)
    combo.place(x=20, y=y)
    entry_c = tk.Entry(form_pencere, width=35)
    entry_c.place(x=150, y=y)
    entry_q = tk.Entry(form_pencere, width=10)
    entry_q.place(x=460, y=y)
    entry_u = tk.Entry(form_pencere, width=10)
    entry_u.place(x=550, y=y)

    def on_select(event=None):
        kod = combo.get()
        entry_c.delete(0, tk.END)
        entry_c.insert(0, get_urun_aciklama(kod))
        entry_u.delete(0, tk.END)
        entry_u.insert(0, "ADET")

    combo.bind("<<ComboboxSelected>>", on_select)
    malzeme_satirlari.append((combo, entry_c, entry_q, entry_u))

def malzeme_satiri_kaldir():
    if malzeme_satirlari:
        for w in malzeme_satirlari.pop():
            w.destroy()

# --- ÜRÜN YÖNETİMİ PENCERESİ ---
def urun_yonetimi_penceresi():
    win = tk.Toplevel(form_pencere)
    win.title("Ürün Yönetimi")
    win.geometry("400x350")

    urun_list = tk.Listbox(win)
    urun_list.pack(fill=tk.BOTH, expand=True, padx=10, pady=(10, 5))

    def liste_guncelle():
        urun_list.delete(0, tk.END)
        conn = sqlite3.connect(ORDER_DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT kod, aciklama FROM urunler ORDER BY kod")
        for kod, aciklama in cur.fetchall():
            urun_list.insert(tk.END, f"{kod} - {aciklama}")
        conn.close()

    liste_guncelle()

    kod_entry = tk.Entry(win)
    kod_entry.pack(pady=(10, 2))
    aciklama_entry = tk.Entry(win)
    aciklama_entry.pack(pady=(0, 5))

    def urun_ekle():
        kod = kod_entry.get().strip()
        aciklama = aciklama_entry.get().strip()
        if kod and aciklama:
            conn = sqlite3.connect(ORDER_DB_PATH)
            cur = conn.cursor()
            cur.execute("REPLACE INTO urunler(kod, aciklama) VALUES (?, ?)", (kod, aciklama))
            conn.commit()
            conn.close()
            liste_guncelle()
            kod_entry.delete(0, tk.END)
            aciklama_entry.delete(0, tk.END)

    def urun_secili_getir():
        sel = urun_list.curselection()
        if sel:
            secili = urun_list.get(sel)
            kod, aciklama = secili.split(" - ", 1)
            kod_entry.delete(0, tk.END)
            kod_entry.insert(0, kod)
            aciklama_entry.delete(0, tk.END)
            aciklama_entry.insert(0, aciklama)

    def urun_sil():
        sel = urun_list.curselection()
        if sel:
            secili = urun_list.get(sel)
            kod = secili.split(" - ", 1)[0]
            if messagebox.askyesno("Sil", f"{kod} kodlu ürünü silmek istiyor musunuz?"):
                conn = sqlite3.connect(ORDER_DB_PATH)
                cur = conn.cursor()
                cur.execute("DELETE FROM urunler WHERE kod=?", (kod,))
                conn.commit()
                conn.close()
                liste_guncelle()
                kod_entry.delete(0, tk.END)
                aciklama_entry.delete(0, tk.END)

    tk.Button(win, text="Ekle / Güncelle", command=urun_ekle).pack(pady=5)
    tk.Button(win, text="Seçiliyi Yükle", command=urun_secili_getir).pack(pady=5)
    tk.Button(win, text="Seçiliyi Sil", command=urun_sil).pack(pady=5)

# --- ORDER LIST FUNCTIONS ---
def get_all_barkods():
    conn = sqlite3.connect(ORDER_DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT barkod FROM orders ORDER BY barkod DESC")
    lst = [r[0] for r in cur.fetchall()]
    conn.close()
    return lst

editing = False
selected_barkod = None

def load_order(barkod):
    global editing, selected_barkod
    editing = True
    selected_barkod = barkod
    while malzeme_satirlari:
        malzeme_satiri_kaldir()
    conn = sqlite3.connect(ORDER_DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT musteri, siparis_tarihi, cikis_tarihi, aciklama, iletisim, nakliye FROM orders WHERE barkod = ?", (barkod,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return
    entry_musteri.delete(0, tk.END); entry_musteri.insert(0, row[0])
    entry_cikis.delete(0, tk.END); entry_cikis.insert(0, row[2])
    entry_aciklama.delete(0, tk.END); entry_aciklama.insert(0, row[3])
    ilt = row[4].split("\n")
    if len(ilt) >= 3:
        entry_adsoyad.delete(0, tk.END); entry_adsoyad.insert(0, ilt[0].split(': ')[1] if ': ' in ilt[0] else "")
        entry_tel.delete(0, tk.END); entry_tel.insert(0, ilt[1].split(': ')[1] if ': ' in ilt[1] else "")
        entry_konum.delete(0, tk.END); entry_konum.insert(0, ilt[2].split(': ')[1] if ': ' in ilt[2] else "")
    combo_nakliye.set(row[5])
    cur.execute("SELECT urun_kod, cinsi, miktar, birim FROM order_items WHERE barkod = ?", (barkod,))
    for kod, cinsi, miktar, birim in cur.fetchall():
        malzeme_satiri_ekle()
        combo, e1, e2, e3 = malzeme_satirlari[-1]
        combo.set(kod)
        e1.delete(0, tk.END); e1.insert(0, cinsi)
        e2.delete(0, tk.END); e2.insert(0, miktar)
        e3.delete(0, tk.END); e3.insert(0, birim)
    conn.close()
    pdf_btn.config(text="GÜNCELLE")

# --- BARCODE & PDF ---
def barkod_uret(kod):
    return Code128(kod, writer=ImageWriter()).save(kod)

def pdf_olustur(form):
    dosya = f"{form['barkod']}_Müşteri_Sipariş_Formu.pdf"
    pdf_canvas = canvas.Canvas(dosya, pagesize=A4)
    w, h = A4

    pdf_canvas.drawImage(resource_path("Logo.png"), 40, h - 80, width=60, height=60, mask='auto')
    pdf_canvas.setFont("DejaVu", 16)
    pdf_canvas.drawCentredString(w / 2, h - 40, "MALZEME TALEP FORMU")

    pdf_canvas.setFont("DejaVu", 9)
    x0, y0 = w - 190, h - 120
    box_w, box_h = 160, 80
    labs = ["Doküman No", "Yayın Tarihi", "Revizyon No", "Revizyon Tarihi", "Sayfa No"]
    vals = [form['dokuman_no'], form['yayin_tarihi'], form['revizyon_no'], form['revizyon_tarihi'], form['sayfa_no']]

    rows = len(labs)
    cell_h = box_h / rows
    left_w = box_w / 2
    pad = 5
    font_sz = 9
    font_off = (cell_h - font_sz) / 2

    pdf_canvas.rect(x0, y0, box_w, box_h)
    for j in range(1, rows):
        y_line = y0 + j * cell_h
        pdf_canvas.line(x0, y_line, x0 + box_w, y_line)
    pdf_canvas.line(x0 + left_w, y0, x0 + left_w, y0 + box_h)

    for i, (label, value) in enumerate(zip(labs, vals)):
        y_text = y0 + box_h - (i + 0.5) * cell_h - font_off
        pdf_canvas.drawString(x0 + pad, y_text, label)
        pdf_canvas.drawString(x0 + left_w + pad, y_text, value)

    pdf_canvas.setFont("DejaVu", 10)
    y = h - 140
    bilgiler = [
        ("Sipariş Numarası", form['barkod']),
        ("Üretici / Müşteri", form['musteri']),
        ("Siparişi Alan", form['siparisi_alan']),
        ("Sipariş Tarihi", form['siparis_tarihi']),
        ("Çıkış Tarihi", form['cikis_tarihi']),
    ]
    for label, value in bilgiler:
        pdf_canvas.drawString(30, y, f"{label} : {value}")
        y -= 15

    y -= 10
    for txt, x in [("Ürün Kodu", 30), ("Cinsi", 130), ("Miktar", 400), ("Birim", 470)]:
        pdf_canvas.drawString(x, y, txt)

    for m, cinsi in zip(form['malzemeler'], form['cinsler']):
        y -= 20
        pdf_canvas.rect(30, y, 80, 20)
        pdf_canvas.rect(110, y, 290, 20)
        pdf_canvas.rect(400, y, 50, 20)
        pdf_canvas.rect(450, y, 50, 20)
        pdf_canvas.drawString(35, y + 5, m['kod'])
        pdf_canvas.drawString(115, y + 5, cinsi)
        pdf_canvas.drawString(405, y + 5, m['miktar'])
        pdf_canvas.drawString(455, y + 5, m['birim'])

    y -= 30
    pdf_canvas.drawString(30, y, f"Açıklama: {form['aciklama']}")
    y -= 30
    pdf_canvas.drawString(30, y, "Müşteri İletişim Bilgileri:")
    for line in form['iletisim'].split("\n"):
        y -= 15
        pdf_canvas.drawString(40, y, line)

    y -= 20
    pdf_canvas.drawString(30, y, f"Nakliye Durumu : {form['nakliye']}")

    y -= 80
    pdf_canvas.rect(30, y, 300, 60)
    pdf_canvas.drawString(35, y + 45, "Onay Bölüm Şefi   [ ] Uygundur    [ ] Uygun Değildir")
    pdf_canvas.drawString(35, y + 30, "Ad Soyad : Ceyhun Kiritli")
    pdf_canvas.drawString(35, y + 15, "Tarih:")
    pdf_canvas.drawString(35, y, "İmza:")

    bf = f"{form['barkod']}.png"
    if os.path.exists(bf):
        pdf_canvas.drawImage(bf, 400, 30, width=120, height=40)

    pdf_canvas.save()

# --- LIST WINDOW ---
def open_list_window():
    list_win = tk.Toplevel(form_pencere)
    list_win.title("Sipariş Listesi")
    list_win.geometry("300x400")

    search_var = tk.StringVar()
    search_entry = tk.Entry(list_win, textvariable=search_var)
    search_entry.pack(fill=tk.X, padx=5, pady=(5, 0))

    lb = tk.Listbox(list_win)
    lb.pack(fill=tk.BOTH, expand=True)

    def filter_list(event=None):
        query = search_var.get().lower()
        lb.delete(0, tk.END)
        for barkod in get_all_barkods():
            if query in barkod.lower():
                lb.insert(tk.END, barkod)

    search_entry.bind("<KeyRelease>", filter_list)
    filter_list()

    def on_load():
        sel = lb.curselection()
        if sel:
            load_order(lb.get(sel))
            list_win.destroy()

    tk.Button(list_win, text="Yükle", command=on_load).pack(pady=5)

# --- CREATE / UPDATE LOGIC ---
def pdf_olustur_gui():
    global editing, selected_barkod
    try:
        malz, cinsl = [], []
        for combo, ec, eq, eu in malzeme_satirlari:
            k = combo.get().strip(); q = eq.get().strip(); u = eu.get().strip()
            if k and q:
                malz.append({'kod': k, 'miktar': q, 'birim': u})
                cinsl.append(ec.get().strip())
        if not malz:
            return messagebox.showerror("Hata", "Malzeme ekleyin.")
        barkod = selected_barkod if editing else sayac_guncelle(get_current_user() or "unknown")
        form = {
            'barkod': barkod,
            'dokuman_no': 'FR 13',
            'yayin_tarihi': '04.05.2025',
            'revizyon_no': '0',
            'revizyon_tarihi': '---',
            'sayfa_no': '1/1',
            'musteri': entry_musteri.get().strip(),
            'siparisi_alan': get_current_user(),
            'siparis_tarihi': datetime.now().strftime("%d.%m.%Y"),
            'cikis_tarihi': entry_cikis.get(),
            'aciklama': entry_aciklama.get().strip(),
            'iletisim': f"Ad Soyad: {entry_adsoyad.get().strip()}\nTelefon: {entry_tel.get().strip()}\nKonum: {entry_konum.get().strip()}",
            'nakliye': combo_nakliye.get().strip(),
            'malzemeler': malz,
            'cinsler': cinsl
        }
        barkod_uret(barkod)
        pdf_olustur(form)
        conn = sqlite3.connect(ORDER_DB_PATH)
        cur = conn.cursor()
        cur.execute("REPLACE INTO orders VALUES(?,?,?,?,?,?,?,?)", (
            barkod, form['musteri'], form['siparisi_alan'], form['siparis_tarihi'],
            form['cikis_tarihi'], form['aciklama'], form['iletisim'], form['nakliye']
        ))
        cur.execute("DELETE FROM order_items WHERE barkod=?", (barkod,))
        for m, c in zip(form['malzemeler'], form['cinsler']):
            cur.execute(
                "INSERT INTO order_items(barkod,urun_kod,cinsi,miktar,birim) VALUES(?,?,?,?,?)",
                (barkod, m['kod'], c, m['miktar'], m['birim'])
            )
        conn.commit()
        conn.close()
        os.makedirs(ORDERS_FOLDER, exist_ok=True)
        od = os.path.join(ORDERS_FOLDER, barkod)
        os.makedirs(od, exist_ok=True)
        pdf_name = f"{barkod}_Müşteri_Sipariş_Formu.pdf"
        if os.path.exists(pdf_name):
            os.replace(pdf_name, os.path.join(od, pdf_name))
        if os.path.exists(f"{barkod}.png"):
            os.replace(f"{barkod}.png", os.path.join(od, f"{barkod}.png"))
        messagebox.showinfo("Başarılı", f"Sipariş '{barkod}' kaydedildi.")
        editing = False; selected_barkod = None; pdf_btn.config(text="PDF OLUŞTUR")
        if get_setting("auto_open_folder") == '1':
            try:
                os.startfile(od)
            except Exception:
                pass
    except Exception as e:
        messagebox.showerror("Hata", str(e))

# --- FORM WINDOW ---
def open_form_window():
    global form_pencere, pdf_btn
    global entry_musteri, entry_cikis, entry_aciklama, entry_adsoyad, entry_tel, entry_konum, combo_nakliye
    global editing, selected_barkod, auto_sync_enabled
    editing = False; selected_barkod = None

    def form_temizle():
        global editing, selected_barkod
        entry_musteri.delete(0, tk.END)
        entry_cikis.delete(0, tk.END)
        entry_aciklama.delete(0, tk.END)
        entry_adsoyad.delete(0, tk.END)
        entry_tel.delete(0, tk.END)
        entry_konum.delete(0, tk.END)
        combo_nakliye.set('')
        scan_entry.delete(0, tk.END)
        scan_entry.focus_set()
        while malzeme_satirlari:
            malzeme_satiri_kaldir()
        pdf_btn.config(text="PDF OLUŞTUR")
        editing = False
        selected_barkod = None

    form_pencere = tk.Toplevel(login_pencere)
    form_pencere.title("Linofleks Sipariş Formu")
    form_pencere.geometry("900x700")
    form_pencere.configure(bg="#f4f4f4")

    notebook = ttk.Notebook(form_pencere)
    notebook.place(x=10, y=10, width=880, height=650)

    # --- Sipariş Tab ---
    siparis_frame = tk.Frame(notebook, bg="#f4f4f4")
    notebook.add(siparis_frame, text="Sipariş")

    # Barkod scan
    scan_entry = tk.Entry(siparis_frame)
    scan_entry.place(x=20, y=60, width=200)
    scan_entry.focus()

    def on_scan(event):
        barkod = scan_entry.get().strip()
        if barkod:
            load_order(barkod)
            scan_entry.delete(0, tk.END)

    scan_entry.bind("<Return>", on_scan)

    img = ImageTk.PhotoImage(Image.open(resource_path("Logo.png")))
    tk.Label(siparis_frame, image=img, bg="#f4f4f4").place(x=20, y=10)
    form_pencere.logo = img

    labels = [("Müşteri Adı:", 110), ("Çıkış Tarihi:", 140), ("Açıklama:", 170),
              ("Ad Soyad:", 200), ("Telefon:", 230), ("Konum:", 260)]
    for text, y in labels:
        tk.Label(siparis_frame, text=text).place(x=20, y=y)
    entry_musteri = tk.Entry(siparis_frame, width=40); entry_musteri.place(x=150, y=110)
    entry_cikis = tk.Entry(siparis_frame, width=20); entry_cikis.place(x=150, y=140)
    entry_aciklama = tk.Entry(siparis_frame, width=20); entry_aciklama.place(x=150, y=170)
    entry_adsoyad = tk.Entry(siparis_frame, width=20); entry_adsoyad.place(x=150, y=200)
    entry_tel = tk.Entry(siparis_frame, width=20); entry_tel.place(x=150, y=230)
    entry_konum = tk.Entry(siparis_frame, width=20); entry_konum.place(x=150, y=260)
    tk.Label(siparis_frame, text="Nakliye Durumu:").place(x=20, y=290)
    combo_nakliye = ttk.Combobox(siparis_frame, values=["Fabrika", "Müşteri"], state="readonly"); combo_nakliye.place(x=150, y=290)

    tk.Button(siparis_frame, text="Sipariş Listesi", bg="#0077b6", fg="white", command=open_list_window).place(x=700, y=20)
    pdf_btn = tk.Button(siparis_frame, text="PDF OLUŞTUR", bg="#b20000", fg="white", font=("Arial", 9, "bold"), command=pdf_olustur_gui)
    pdf_btn.place(x=700, y=60)
    tk.Button(siparis_frame, text="+ Malzeme Ekle", bg="#0077b6", fg="white", command=malzeme_satiri_ekle).place(x=700, y=100)
    tk.Button(siparis_frame, text="- Malzeme Kaldır", bg="#999999", fg="white", command=malzeme_satiri_kaldir).place(x=700, y=140)
    tk.Button(siparis_frame, text="TEMİZLE", bg="#666666", fg="white", command=form_temizle).place(x=700, y=180)
    tk.Button(siparis_frame, text="Ürün Yönetimi", bg="#444444", fg="white", command=urun_yonetimi_penceresi).place(x=700, y=220)

    # Sync status label under Ürün Yönetimi button
    status_label = tk.Label(siparis_frame, text="Otomatik senkron kapalı.", fg="orange", font=("Arial", 9))
    status_label.place(x=20, y=260)

    for t, x in [("Ürün Kodu", 20), ("Malzeme Cinsi", 150), ("Miktar", 460), ("Birim", 550)]:
        tk.Label(siparis_frame, text=t).place(x=x, y=330)

    # --- Ayarlar Tab ---
    ayarlar_frame = tk.Frame(notebook, bg="#f4f4f4")
    notebook.add(ayarlar_frame, text="Ayarlar")

    tk.Label(ayarlar_frame, text="rclone.conf:").place(x=20, y=40)
    rclone_entry_var = tk.StringVar()
    rclone_entry = tk.Entry(ayarlar_frame, textvariable=rclone_entry_var, state="readonly", width=60)
    rclone_entry.place(x=120, y=40)

    def refresh_rclone_display():
        conf = get_persisted_rclone_conf()
        if conf:
            rclone_entry_var.set(conf)
        else:
            rclone_entry_var.set("Seçilmedi")

    tk.Button(ayarlar_frame, text="Seç", command=lambda: [ensure_rclone_config(form_pencere), refresh_rclone_display()]).place(x=700, y=36)

    auto_sync_var = tk.IntVar(value=int(get_setting("auto_sync_enabled") or 0))
    def on_auto_sync_toggle():
        global auto_sync_enabled
        auto_sync_enabled = bool(auto_sync_var.get())
        set_setting("auto_sync_enabled", "1" if auto_sync_enabled else "0")
        if auto_sync_enabled:
            update_status_label(status_label, "Otomatik senkron açık", success=True)
        else:
            status_label.config(text="Otomatik senkron kapalı.", fg="orange")

    tk.Checkbutton(ayarlar_frame, text="Otomatik Bulut Senkronizasyonu", variable=auto_sync_var,
                   command=on_auto_sync_toggle).place(x=20, y=80)

    refresh_rclone_display()

    # Start background sync thread
    threading.Thread(target=auto_sync_thread, args=(form_pencere, status_label), daemon=True).start()

# --- LOGIN SCREEN & UPDATE ---
if __name__ == "__main__":
    VERSIYON_DOSYASI_URL = "https://raw.githubusercontent.com/kyteren/Linofleks-FIK/main/releases/versiyon.txt"
    ZIP_URL = "https://github.com/kyteren/Linofleks-FIK/raw/main/releases/yeni_versiyon.zip"
    LOCAL_VERSIYON = "7.3.0"

    login_pencere = tk.Tk()
    login_pencere.withdraw()

    temp_root = tk.Tk()
    temp_root.withdraw()
    cleanup_old_versions(LOCAL_VERSIYON)
    temp_root.destroy()

    def download_update(remote_ver):
        try:
            indirilen_zip = "yeni_versiyon.zip"
            temp_name = indirilen_zip + ".part"
            with urllib.request.urlopen(ZIP_URL) as resp:
                total = int(resp.getheader("Content-Length") or 0)
                dl = 0
                login_pencere.after(0, lambda: login_pencere.deiconify())
                with open(temp_name, "wb") as out:
                    while True:
                        chunk = resp.read(8192)
                        if not chunk:
                            break
                        out.write(chunk)
                        dl += len(chunk)
                        if total:
                            pct = int(dl * 100 / total)
                            login_pencere.after(0, lambda p=pct: login_pencere.title(f"Güncelleme indiriliyor... %{p}"))
            os.replace(temp_name, indirilen_zip)
            login_pencere.after(0, lambda: messagebox.showinfo("Güncelleme", "Güncelleme indirildi. Kurulum başlatılıyor..."))
            subprocess.Popen([UPDATER_CMD, indirilen_zip], cwd=os.getcwd())
            sys.exit()
        except Exception as e:
            login_pencere.after(0, lambda: messagebox.showerror("Güncelleme Hatası", str(e)))

    def check_update_and_prompt():
        try:
            url = VERSIYON_DOSYASI_URL + f"?t={int(time.time())}"
            with urllib.request.urlopen(url, timeout=10) as resp:
                remote_ver = resp.read().decode().strip()
            if remote_ver != LOCAL_VERSIYON:
                def ask_and_maybe_download():
                    if messagebox.askyesno("Güncelleme", f"Yeni sürüm ({remote_ver}) mevcut. Güncellemek ister misin?"):
                        threading.Thread(target=download_update, args=(remote_ver,), daemon=True).start()
                login_pencere.after(0, ask_and_maybe_download)
        except Exception as e:
            login_pencere.after(0, lambda: messagebox.showerror("Güncelleme Hatası", str(e)))

    threading.Thread(target=check_update_and_prompt, daemon=True).start()

    # Show login UI
    login_pencere.deiconify()
    login_pencere.title("Kullanıcı Girişi")
    login_pencere.geometry("350x230")
    ttk.Label(login_pencere, text="Kullanıcı Seçin:").pack(pady=(20, 5))
    combo_k = ttk.Combobox(login_pencere, values=get_users(), state="readonly")
    combo_k.pack(pady=5)
    tk.Button(login_pencere, text="+ Yeni Kullanıcı", command=lambda: add_user(simpledialog.askstring("Yeni Kullanıcı", "Kullanıcı adını girin:"))).pack(pady=5)
    tk.Button(login_pencere, text="Giriş Yap", command=lambda: [set_current_user(combo_k.get()), login_pencere.withdraw(), open_form_window()]).pack(pady=15)
    auto_var = tk.IntVar(value=int(get_setting("auto_open_folder") or 0))
    tk.Label(login_pencere, text=f"Sürüm: {LOCAL_VERSIYON}", fg="gray").pack(side="bottom", pady=(0, 5))
    tk.Checkbutton(
        login_pencere,
        text="PDF klasörünü otomatik aç",
        variable=auto_var,
        command=lambda: set_setting("auto_open_folder", str(auto_var.get()))
    ).pack(pady=5)
    login_pencere.mainloop()
